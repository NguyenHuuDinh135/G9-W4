"""
GeekBrain AI Assistant — Lambda Handler
Approach: Bedrock KB Retrieve API + Custom Prompt + DeepSeek R1
Supports L1 (single-doc retrieval) and L2 (multi-doc synthesis + conflict resolution)
"""

import json
import os
import re
import boto3

# Environment variables set by Terraform
KNOWLEDGE_BASE_ID = os.environ.get("KNOWLEDGE_BASE_ID", "")
LLM_MODEL_ID = os.environ.get("LLM_MODEL_ID", "deepseek.r1-v1:0")
AWS_REGION = os.environ.get("AWS_REGION_NAME", "us-east-1")
RETRIEVAL_K = int(os.environ.get("RETRIEVAL_K", "10"))

bedrock_agent_runtime = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)
bedrock_runtime = boto3.client("bedrock-runtime", region_name=AWS_REGION)

SYSTEM_PROMPT = """You are GeekBrain AI Assistant. You answer questions about GeekBrain — a fintech startup running six production services.

RULES:
1. Answer using ONLY the provided context from the knowledge base. Do NOT guess or make up information.
2. Always cite the source document name(s) in your answer using the format [source: filename.md].
3. When multiple documents provide DIFFERENT information about the same topic:
   - Check if one document is marked as "archived", "superseded", or "v1" — prefer the current/latest version.
   - Check document dates — prefer the most recent.
   - If you cannot determine which is correct, state BOTH values and explain the discrepancy.
4. If the context does not contain the answer, say: "I don't have enough information in the knowledge base to answer this question."
5. Be concise but complete. Use bullet points for complex answers.
6. For questions requiring information from multiple documents, synthesize a comprehensive answer that references all relevant sources."""

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Content-Type": "application/json",
}


def handler(event, context):
    """Lambda handler for API Gateway proxy integration."""
    # Handle CORS preflight
    if event.get("httpMethod") == "OPTIONS":
        return {"statusCode": 200, "headers": CORS_HEADERS, "body": ""}

    try:
        body = json.loads(event.get("body", "{}"))
        question = body.get("question", "").strip()

        if not question:
            return _response(400, {"error": "Missing 'question' field"})

        if not KNOWLEDGE_BASE_ID:
            return _response(500, {"error": "KNOWLEDGE_BASE_ID not configured"})

        # Step 1: Retrieve relevant chunks from Bedrock KB
        chunks, sources = retrieve_chunks(question)

        # Step 2: Build context from chunks
        context_text = format_context(chunks)

        # Step 3: Call DeepSeek R1 via Bedrock with custom prompt
        answer = call_llm(question, context_text)

        # Step 4: Extract source citations from answer
        cited_sources = extract_sources(answer, sources)

        return _response(200, {
            "answer": answer,
            "sources": cited_sources,
            "chunks_used": len(chunks),
        })

    except Exception as e:
        print(f"Error: {e}")
        return _response(500, {"error": str(e)})


def retrieve_chunks(question):
    """Call Bedrock KB Retrieve API to get relevant document chunks."""
    response = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=KNOWLEDGE_BASE_ID,
        retrievalQuery={"text": question},
        retrievalConfiguration={
            "vectorSearchConfiguration": {"numberOfResults": RETRIEVAL_K}
        },
    )

    chunks = []
    sources = set()
    for result in response.get("retrievalResults", []):
        content = result.get("content", {}).get("text", "")
        location = result.get("location", {})
        score = result.get("score", 0)

        # Extract source filename from S3 URI
        source_uri = location.get("s3Location", {}).get("uri", "")
        source_name = source_uri.split("/")[-1] if source_uri else "unknown"

        chunks.append({
            "text": content,
            "source": source_name,
            "score": score,
        })
        sources.add(source_name)

    return chunks, list(sources)


def format_context(chunks):
    """Format retrieved chunks into a context string for the LLM."""
    if not chunks:
        return "No relevant documents found in the knowledge base."

    parts = []
    for i, chunk in enumerate(chunks, 1):
        parts.append(f"--- Document Chunk {i} [source: {chunk['source']}] ---\n{chunk['text']}")

    return "\n\n".join(parts)


def call_llm(question, context_text):
    """Call DeepSeek R1 via Bedrock Converse API."""
    user_message = f"""Here is the context retrieved from GeekBrain's knowledge base:

{context_text}

Based on the above context, please answer the following question:
{question}"""

    response = bedrock_runtime.converse(
        modelId=LLM_MODEL_ID,
        messages=[
            {"role": "user", "content": [{"text": user_message}]}
        ],
        system=[{"text": SYSTEM_PROMPT}],
        inferenceConfig={
            "maxTokens": 2048,
            "temperature": 0.1,
        },
    )

    output = response.get("output", {}).get("message", {}).get("content", [])
    answer_text = ""
    for block in output:
        if "text" in block:
            answer_text += block["text"]

    # DeepSeek R1 may include <think>...</think> reasoning blocks — strip them
    answer_text = re.sub(r"<think>.*?</think>", "", answer_text, flags=re.DOTALL).strip()

    return answer_text


def extract_sources(answer, all_sources):
    """Extract source document names mentioned in the answer."""
    cited = []
    for source in all_sources:
        if source.replace(".md", "") in answer or source in answer:
            cited.append(source)

    # If no sources explicitly cited, return top sources from retrieval
    if not cited and all_sources:
        cited = all_sources[:3]

    return cited


def _response(status_code, body):
    """Build API Gateway proxy response."""
    return {
        "statusCode": status_code,
        "headers": CORS_HEADERS,
        "body": json.dumps(body),
    }
